"use strict";

$(submit).click(function () {
    alert("Thank you!");
});